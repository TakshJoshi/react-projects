// import React from 'react'
import paul from '../assets/Layer9.png'
const client = () => {
  return (
    <>
        <div className='client'>
            <h3>What Clients Say</h3>
            <h4>&lsquo;&lsquo;</h4>
            <p>Vestibulum id ligula porta felis euismod semper. Morbi leo risu Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores mollitia cum repellat totam dolores quam rem doloribus excepturi illo ipsa velit aspernatur blanditiis explicabo delectus in consequuntur, itaque dolorem nihil?</p>
            <div className='paul'>
                <img src={paul} alt="" />
                <div className='paulh5'><h5>Paul Smith <br />Businessman</h5></div>
                
            </div>
        </div>
    </>
  )
}

export default client